# English Skill Names

| Original file | English skill name | Display title |
| --- | --- | --- |
| `SKILL.md` | `attendance-sync` | Attendance Sync |
| `SKILL (1).md` | `calendar-sync` | Team Calendar Sync |
| `SKILL (2).md` | `drive-structure-sync` | Drive Structure Sync |
| `SKILL (3).md` | `finance-sync` | Finance Sync |
| `SKILL (4).md` | `google-workspace-setup` | Google Workspace Setup |
| `SKILL (5).md` | `permit-sync` | Facility Permit Sync |
| `SKILL (6).md` | `todo-reminder` | Club Todo Reminder |

Each translated skill is stored in a folder whose name matches its YAML `name`, with the entrypoint named `SKILL.md`.

Chinese text remains only where it is an exact operational identifier, such as a Google Sheet tab, column name, status value, filename prefix, or Calendar title marker. Every such identifier is explained in English nearby.
