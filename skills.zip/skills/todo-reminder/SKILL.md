---
name: todo-reminder
description: Run the club’s scheduled Todo reminder workflow. On the first Sunday of a month, import new monthly and recurring tasks from the Club Management Guide and invoke drive-structure-sync. On every run, invoke calendar-sync, summarize incomplete items due within 14 days or overdue, calculate weekly birthday reminders, and on the monthly run synchronize this and next month’s birthdays to Calendar. Send one concise final status message. Called by cloud cron task 870d54d7 in the jhu-cfc project and available for manual testing.
---

# Club Todo Reminder

Execute the full workflow on every invocation.

## Workflow

1. Run `date +%d` with Bash. A value from `01` through `07` means this run falls on the month’s first Sunday. Record a boolean `monthly_run`.

2. If `monthly_run` is true, synchronize the monthly management guide:

   a. Run `date +%m` and map the month number to the exact Chinese tab name: `1→一月`, `2→二月`, `3→三月`, `4→四月`, `5→五月`, `6→六月`, `7→七月`, `8→八月`, `9→九月`, `10→十月`, `11→十一月`, `12→十二月`.

   b. Read the Club Management Guide, document ID `1xRkUw6-DVUDVe_5kVmElv5UVeiR_ETVxIhIeVU5ln_A`. Use `listTabs` to locate and read both the current month’s tab and `持续性工作(每个月都要做的)` (“Ongoing Work—Repeat Every Month”).

   c. From the month tab, extract concrete one-time tasks that should begin or finish this month. Treat leading phrases such as procurement or recruitment as task categories. Do not add routine per-training or per-match operations such as sign-up chains, backend statistics, or match reports. Extract every ongoing-work item as a task for this month, such as creating the month’s social-media plan and weekly posts.

   d. Read `Sheet1` of the Todo list, spreadsheet ID `1VlysVi6CLT7BT4GbUaVgur_NZlcWfMo9hp1hIQx9a7w`. Before adding each task, check for an existing row with identical task text and the same due-date year and month. Deduplicate by year and month, not year alone, because ongoing tasks recur monthly.

   e. Append remaining tasks in this order: `事项大类`, `具体事项`, `负责人`, `状态`, `预计完成日期`, `备注` (“Category,” “Task,” “Owner,” “Status,” “Due Date,” “Notes”). Set status to `待讨论` (“To Discuss”). Use the role named by the guide. Estimate a concrete date from the guide’s timeline using the current year; when an ongoing item has no timeline, use the last day of the current month. Note whether the source was the month tab or the ongoing-work tab and preserve key details.

   f. Record the number of tasks actually added, including zero.

3. If `monthly_run` is true, invoke `drive-structure-sync` and execute it completely. Retain its list of checked areas, corrections, and unresolved anomalies for the final message. Skip this step on other Sundays.

4. On every run, invoke `calendar-sync` and execute it completely. It reloads the team spreadsheet, management guide, and social-media Todo items; creates or updates calendar events; and never deletes events. Retain its created and updated counts and its full list of events marked obsolete but not deleted, including an empty list.

5. Prepare weekly Todo reminders on every run:

   a. Reread the latest Todo sheet, including any rows created in step 2.
   b. Select every row whose status is neither `已完成` nor `不再需要` (“Completed” or “No Longer Needed”). This includes `待讨论`, `待执行`, `紧急`, and `进行中` (“To Discuss,” “To Do,” “Urgent,” and “In Progress”).
   c. Highlight incomplete tasks whose due dates are within the next 14 days or already overdue.

6. Prepare birthday reminders on every run. Steps a–d are read-only; step e writes Calendar events only during a monthly run.

   a. Reread `大名单及个人信息` (“Roster and Personal Information”) in the current team spreadsheet. For each row, use `prefered name` when present, otherwise `中文全名` (“Full Chinese Name”), and read `生日` (“Birthday”). Never use a cached roster.

   b. Process only birthdays from which a precise month and day can be extracted from a complete `M/D/YYYY` value. Skip blanks and year-only values such as `YYYY(仅年份已知,来源:...)`; do not guess. Include all people recorded in the roster, including students, alumni, and community players, without filtering by current playing status.

   c. Calculate birthdays occurring from today through the next seven days, inclusive, using the correct month- and year-boundary logic. Sort them by date as `weekly_birthdays`.

   d. If `monthly_run` is true, also calculate all birthdays in the current calendar month as `monthly_birthdays`. It is acceptable for the two lists to overlap.

   e. If `monthly_run` is true, synchronize birthday events for the current and following calendar months:

   - Reuse only the roster data freshly read in step 6a. Determine the correct year for each occurrence, including a December-to-January transition.
   - Create only the upcoming single occurrence; do not add a yearly recurrence rule. Next year’s monthly run will create that year’s occurrence from the then-current roster.
   - For each person, call `listEvents` over the two-month date range and look for a title containing `生日:<name>` (“Birthday:<name>”).
   - If an event exists on the correct date, leave it unchanged.
   - If missing, create an all-day event using `date`, not `dateTime`, titled `生日:<name>`, and cite `2026-2027 球队信息表 → 大名单及个人信息` as the source in its description.
   - If the event exists on the wrong date, update it in place with `updateEvent`; do not delete and recreate it.
   - Record the number created and updated.

7. Send exactly one concise final message in this order, omitting empty optional sections where allowed:

   - On a monthly run, if step 2 added tasks, state that the current month’s tasks were imported from the management guide, give the count, and ask the manager to review them. If none were added, optionally state that there were no new monthly tasks.
   - On a monthly run, include a nonempty `本月生日` (“Birthdays This Month”) list formatted as `Name (M/D)`.
   - Include a nonempty `本周生日` (“Birthdays This Week”) list in the same format. Do not announce that the list is empty.
   - On a monthly run, mention birthday Calendar counts only if events were created or updated.
   - Summarize the total number of incomplete Todo items and counts by status. List only items due within 14 days or overdue, with task, owner, and due date; clearly label overdue items.
   - Summarize Calendar changes from `calendar-sync`, grouped by training, match, or social-media task. List obsolete events with title and link and tell the manager to delete them manually. If nothing changed, optionally say that the Calendar schedule is unchanged.
   - On a monthly run, summarize Drive-structure corrections. Call out unresolved errors separately for human confirmation. If nothing changed, optionally say that the Drive structure is unchanged.
   - Include the Todo Sheet link: https://docs.google.com/spreadsheets/d/1VlysVi6CLT7BT4GbUaVgur_NZlcWfMo9hp1hIQx9a7w/edit

Do not list every incomplete task. Keep the message focused on counts, urgent items, near-term deadlines, overdue work, and material Calendar or Drive changes.
